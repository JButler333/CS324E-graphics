HOW TO PLAY:
double click on group_19_assignment_7 to open file in processing.

Press the play button in the top left corner of the UI.

to move the blocks, press up, down, left, and right.

to click and interact with buttons, press the left mouse key on the button.