TO RUN:

Open group_19_assignment5.pde in processing or by double-clicking file.
Press play in top left corner.