To run:

Open Proccessing file within this folder, press the play button on the top left corner.

To stop animation, exit window.